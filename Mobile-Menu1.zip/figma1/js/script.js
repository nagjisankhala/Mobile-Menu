$(document).ready(function() {
    $(".menu-toggle").click(function() {
        $(".mobile-menu").toggleClass("active");
        $(".overlay").toggleClass("active");
    });
    $(".menu-close").click(function() {
        $(".mobile-menu").toggleClass("active");
        $(".overlay").toggleClass("active");
    });
    $(document).on("click", function(event) {
        if (!$(event.target).closest(".mobile-menu").length && !$(event.target).closest(".menu-toggle").length) {
            $(".mobile-menu").removeClass("active");
            $(".overlay").removeClass("active");
        }
    });
});